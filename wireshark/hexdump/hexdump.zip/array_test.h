struct array_test {
    char chararr1[16];
    //int intarr2[4][4];
    int intarr2[2][2][2][2];
    char chararr3[2][3];
    float floatarr4[1][2][3];
};
