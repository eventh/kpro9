struct bitstring_test {
    int id;
    int flags;
    short color1;
    short color2;
};
