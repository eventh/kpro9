
enum Months { JAN = 1, FEB, MAR, APR, MAY, JUN, JUL, AUG, SEP, OCT, NOV, DEC = 20 };

struct cenum_test {
    int id;
    enum Months mnd;
};