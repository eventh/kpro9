#define ARRAY_SIZE 2

enum repeat{and=1, elseif, in=412};

struct local {
    int end;
};

struct keyword_test {
    int in;
    int until[ARRAY_SIZE][ARRAY_SIZE];
    int _VERSION;

    enum repeat function;

    int false2;

    struct local or;

    int and;
    int _and;

    int not;
};
