#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "alignment_test.h"
#include "array_test.h"
#include "bitstring_test.h"
#include "cenum_test.h"
#include "enum_test.h"
#include "keyword_test.h"
#include "platform_test.h"
#include "range_test.h"
#include "simple.h"
#include "struct_test.h"
#include "struct_within_struct_test.h"
#include "trailer_test.h"
#include "typedef_test.h"
#include "union_test.h"
#include "custom_lua_test.h"

#if _WIN64
#define PLATFORMFLAG 2
#elif _WIN32
#define PLATFORMFLAG 1
#elif _sun /* Fix this */
#define PLATFORMFLAG 3
#elif _sun /* Fix this */
#define PLATFORMFLAG 4
#elif __sparc__
#define PLATFORMFLAG 5
#elif __APPLE__
#define PLATFORMFLAG 6
#elif __linux__
#define PLATFORMFLAG 7
#else
#define  PLATFORMFLAG 0
#endif

void hexdump (unsigned char *data, unsigned long length, unsigned char *mid)
{
	unsigned int i = 0;
	FILE *fp;

	fp=fopen("ascii.hexdump", "a");
	fprintf(fp,"0000 01 ");
	fprintf(fp,"0%d ", PLATFORMFLAG);

	/* Endian handling */
	#if __sparc
	fprintf(fp,"%02x ", mid[0]);
	fprintf(fp,"%02x ", mid[1]);
	#else
	fprintf(fp,"%02x ", mid[1]);
	fprintf(fp,"%02x ", mid[0]);
	#endif

	for (i = 0; i < length; i++) {
		fprintf(fp,"%02x ", data[i]);
	}

	fprintf(fp,"\n\n");
	fclose(fp);
}

void init_basic(short id)
{
	struct basic *basic = (struct basic *)malloc(sizeof(struct basic));
	memset(basic, 0, sizeof(struct basic));
	basic->name = 'a';
	basic->white = 'b';
	basic->grey = 'c';
	basic->z = 1;
	basic->size = 2;
	basic->y = 3;
	basic->x = 4;
	basic->yellow = 5;
	basic->black = 6;
	basic->orange = 7;
	basic->red = 8;
	basic->pink = 9;
	basic->blue = 10;
	basic->tester = 11;
	basic->in = 12.0;
	basic->end = 13.0;

	hexdump((unsigned char *)basic, sizeof (struct basic), (unsigned char *)(&id));
}

void init_platform_test1(short id) 
{
	struct platform_test *pt = (struct platform_test *)malloc(sizeof(struct platform_test));
	memset(pt, 0, sizeof(struct platform_test));
	pt->bytes = 3.14;
	pt->a = 2;
	#if _WIN32
	pt->win_float = 28.10f;
	#else
    pt->plat = 0;
	#endif
    pt->b = 'b';
	#if __ia64
    pt->intel64 = 1;
	#endif
	
	//Union
	pt->anom.a = 10;
	
	pt->deff = 800;
	#if _M_IX86
    pt->intel = 386;
	#endif
	#if __sparc
    pt->sparc = 64;
	#endif
	#if _WIN64
    pt->win64 = 311;
	#endif

	hexdump((unsigned char *)pt, sizeof (struct platform_test), (unsigned char *)(&id));
}

void init_platform_test2(short id) 
{
	struct platform_test *pt = (struct platform_test *)malloc(sizeof(struct platform_test));
	memset(pt, 0, sizeof(struct platform_test));
	pt->bytes = 3.14;
	pt->a = 2;
	#if _WIN32
	pt->win_float = 28.10f;
	#else
    pt->plat = 0;
	#endif
    pt->b = 'b';
	#if __ia64
    pt->intel64 = 1;
	#endif
	
	//Union
	#if __sun
	pt->anom.something = 3.11;
	#elif __APPLE__
	pt->anom.apple = 2:
	#else
	pt->anom.arr[0] = 't';
	pt->anom.arr[1] = 'e';
	pt->anom.arr[2] = 's';
	pt->anom.arr[3] = 't';
	#endif
	
	pt->deff = 800;
	#if _M_IX86
    pt->intel = 386;
	#endif
	#if __sparc
    pt->sparc = 64;
	#endif
	#if _WIN64
    pt->win64 = 311;
	#endif

	hexdump((unsigned char *)pt, sizeof (struct platform_test), (unsigned char *)(&id));
}

void init_alignment_test1(short id) 
{
	struct alignment_test *at = (struct alignment_test *)malloc(sizeof(struct alignment_test));
	memset(at, 0, sizeof(struct alignment_test));
	at->a = 1;
	at->b = 2;
	at->c = 'a';
	at->d = 'b';
	at->e = 'c';
	at->f.a = 11;
	at->f.b = 12;
	at->f.c = 13;
	at->f.d = 14;
	at->f.e = 'x';

	hexdump((unsigned char *)at, sizeof (struct alignment_test), (unsigned char *)(&id));
}

void init_alignment_test2(short id) 
{
	struct alignment_test *at = (struct alignment_test *)malloc(sizeof(struct alignment_test));
	memset(at, 0, sizeof(struct alignment_test));
	at->a = -1;
	at->b = -2;
	at->c = 'h';
	at->d = 'e';
	at->e = 'i';
	at->f.a = 2;
	at->f.b = 3;
	at->f.c = 5;
	at->f.d = 8;
	at->f.e = '4';

	hexdump((unsigned char *)at, sizeof (struct alignment_test), (unsigned char *)(&id));
}

void init_array_test(short id) 
{
	struct array_test *at = (struct array_test *)malloc(sizeof(struct array_test));
	memset(at, 0, sizeof(struct array_test));

	strcpy(at->chararr1 ,"AaBbCcDdEe");
	at->intarr2[0][0][0][0] = 1;
	at->intarr2[0][0][0][1] = 2;
	at->intarr2[0][0][1][0] = 3;
	at->intarr2[0][0][1][1] = 4;
	at->intarr2[0][1][0][0] = 5;
	at->intarr2[0][1][0][1] = 6;
	at->intarr2[0][1][1][0] = 7;
	at->intarr2[0][1][1][1] = 8;
	at->intarr2[1][0][0][0] = 9;
	at->intarr2[1][0][0][1] = 10;
	at->intarr2[1][0][1][0] = 11;
	at->intarr2[1][0][1][1] = 12;
	at->intarr2[1][1][0][0] = 13;
	at->intarr2[1][1][0][1] = 14;
	at->intarr2[1][1][1][0] = 15;
	at->intarr2[1][1][1][1] = 16;
	strcpy(at->chararr3[0], "HEI");
	strcpy(at->chararr3[1], "hei");
	at->floatarr4[0][0][0] = 0.25;
	at->floatarr4[0][0][1] = 0.75;
	at->floatarr4[0][0][2] = 1.25;
	at->floatarr4[0][1][0] = 2.25;
	at->floatarr4[0][1][1] = 5.25;
	at->floatarr4[0][1][2] = 10.25;

	hexdump((unsigned char *)at, sizeof (struct array_test), (unsigned char *)(&id));
}

void init_bitstring_test1(short id) 
{
	struct bitstring_test *bt = (struct bitstring_test *)malloc(sizeof(struct bitstring_test));
	memset(bt, 0, sizeof(struct bitstring_test));

	bt->id = 1;
	bt->flags = 0x00000001;
	bt->color1 = 0xf000;
	bt->color2 = 0x8000;

	hexdump((unsigned char *)bt, sizeof (struct bitstring_test), (unsigned char *)(&id));
}

void init_bitstring_test2(short id) 
{
	struct bitstring_test *bt = (struct bitstring_test *)malloc(sizeof(struct bitstring_test));
	memset(bt, 0, sizeof(struct bitstring_test));

	bt->id = 2;
	bt->flags = 0x00000003;
	bt->color1 = 0x8080;
	bt->color2 = 0x1010;

	hexdump((unsigned char *)bt, sizeof (struct bitstring_test), (unsigned char *)(&id));
}

void init_bitstring_test3(short id) 
{
	struct bitstring_test *bt = (struct bitstring_test *)malloc(sizeof(struct bitstring_test));
	memset(bt, 0, sizeof(struct bitstring_test));

	bt->id = 3;
	bt->flags = 0x000000FF;
	bt->color1 = 0xb011;
	bt->color2 = 0xa111;

	hexdump((unsigned char *)bt, sizeof (struct bitstring_test), (unsigned char *)(&id));
}

void init_bitstring_test4(short id) 
{
	struct bitstring_test *bt = (struct bitstring_test *)malloc(sizeof(struct bitstring_test));
	memset(bt, 0, sizeof(struct bitstring_test));

	bt->id = 4;
	bt->flags = 0x0000020f;
	bt->color1 = 0xd555;
	bt->color2 = 0x6321;

	hexdump((unsigned char *)bt, sizeof (struct bitstring_test), (unsigned char *)(&id));
}

void init_cenum_test1(short id) 
{
	struct cenum_test *ct = (struct cenum_test *)malloc(sizeof(struct cenum_test));
	memset(ct, 0, sizeof(struct cenum_test));

	ct->id = 1;
	ct->mnd = DEC;

	hexdump((unsigned char *)ct, sizeof (struct cenum_test), (unsigned char *)(&id));
}

void init_cenum_test2(short id) 
{
	struct cenum_test *ct = (struct cenum_test *)malloc(sizeof(struct cenum_test));
	memset(ct, 0, sizeof(struct cenum_test));

	ct->id = 2;
	ct->mnd = APR;

	hexdump((unsigned char *)ct, sizeof (struct cenum_test), (unsigned char *)(&id));
}

void init_cenum_test3(short id) 
{
	struct cenum_test *ct = (struct cenum_test *)malloc(sizeof(struct cenum_test));
	memset(ct, 0, sizeof(struct cenum_test));

	ct->id = 3;
	ct->mnd = MAY;

	hexdump((unsigned char *)ct, sizeof (struct cenum_test), (unsigned char *)(&id));
}

void init_cenum_test4(short id) 
{
	struct cenum_test *ct = (struct cenum_test *)malloc(sizeof(struct cenum_test));
	memset(ct, 0, sizeof(struct cenum_test));

	ct->id = 4;
	ct->mnd = JAN;

	hexdump((unsigned char *)ct, sizeof (struct cenum_test), (unsigned char *)(&id));
}

void init_custom_test1(short id) 
{
	struct custom_test *ct = (struct custom_test *)malloc(sizeof(struct custom_test));
	int n;
	memset(ct, 0, sizeof(struct custom_test));
	
	ct->normal = 1;
	ct->special = 0;
	ct->abs = 0x12345678;
	ct->rel = 0x12345678;
	ct->bol = 0;
	ct->all = 0x01;
	ct->truth = FALSE;
	ct->five[0] = 0;
	ct->five[1] = 1;
	ct->five[2] = 2;
	ct->five[3] = 3;
	ct->five[4] = 4;
	ct->pointer = &n;
	strcpy(ct->str[0][0], "aa");
	strcpy(ct->str[0][1], "ab");
	strcpy(ct->str[0][2], "ac");
	strcpy(ct->str[1][0], "ad");
	strcpy(ct->str[1][1], "ae");
	strcpy(ct->str[1][2], "af");
	strcpy(ct->str[2][0], "ag");
	strcpy(ct->str[2][1], "ah");
	strcpy(ct->str[2][2], "ai");
	strcpy(ct->str[3][0], "aj");
	strcpy(ct->str[3][1], "ak");
	strcpy(ct->str[3][2], "al");

	hexdump((unsigned char *)ct, sizeof (struct custom_test), (unsigned char *)(&id));
}

void init_enum_test1(short id) 
{
	struct enum_test *et = (struct enum_test *)malloc(sizeof(struct enum_test));
	memset(et, 0, sizeof(struct enum_test));

	et->id = 1;
	strcpy(et->name, "Erik");
	et->weekday = 2;
	et->number = -1;
	hexdump((unsigned char *)et, sizeof (struct enum_test), (unsigned char *)(&id));
}

void init_enum_test2(short id) 
{
	struct enum_test *et = (struct enum_test *)malloc(sizeof(struct enum_test));
	memset(et, 0, sizeof(struct enum_test));

	et->id = 1;
	strcpy(et->name, "Lars");
	et->weekday = 9;
	et->number = 22;
	hexdump((unsigned char *)et, sizeof (struct enum_test), (unsigned char *)(&id));
}

void init_enum_test3(short id) 
{
	struct enum_test *et = (struct enum_test *)malloc(sizeof(struct enum_test));
	memset(et, 0, sizeof(struct enum_test));

	et->id = 1;
	strcpy(et->name, "Even");
	et->weekday = 6;
	et->number = 5;
	hexdump((unsigned char *)et, sizeof (struct enum_test), (unsigned char *)(&id));
}

void init_enum_test4(short id) 
{
	struct enum_test *et = (struct enum_test *)malloc(sizeof(struct enum_test));
	memset(et, 0, sizeof(struct enum_test));

	et->id = 1;
	strcpy(et->name, "Jaroslav");
	et->weekday = 4;
	et->number = 2;
	hexdump((unsigned char *)et, sizeof (struct enum_test), (unsigned char *)(&id));
}

struct keyword {
	struct keyword_test test;
	char asn[5];
};

void init_keyword_test1(short id) 
{
	struct keyword *kt = (struct keyword *)malloc(sizeof(struct keyword));
	memset(kt, 0, sizeof(struct keyword));

	kt->test.in =1;
	kt->test.until[0][0] = 1;
	kt->test.until[0][1] = 2;
	kt->test.until[1][0] = 3;
	kt->test.until[1][1] = 4;
	kt->test._VERSION = 1;
    kt->test.function = in;
    kt->test.false2 = 1;
	kt->test.or.end = 1;
    kt->test.and = 1;
    kt->test._and = 1;
    kt->test.not = 1;
	strcpy(kt->asn, "\x16\x03\x48\x45\x59");
	hexdump((unsigned char *)kt, sizeof (struct keyword), (unsigned char *)(&id));
}

void init_range_test1(short id) 
{
	struct range_test *rt = (struct range_test *)malloc(sizeof(struct range_test));
	memset(rt, 0, sizeof(struct range_test));

	strcpy(rt->name, "Erik");
	rt->age = -1;

	hexdump((unsigned char *)rt, sizeof (struct range_test), (unsigned char *)(&id));
}

void init_range_test2(short id) 
{
	struct range_test *rt = (struct range_test *)malloc(sizeof(struct range_test));
	memset(rt, 0, sizeof(struct range_test));

	strcpy(rt->name, "Lars");
	rt->age = 50;

	hexdump((unsigned char *)rt, sizeof (struct range_test), (unsigned char *)(&id));
}

void init_range_test3(short id) 
{
	struct range_test *rt = (struct range_test *)malloc(sizeof(struct range_test));
	memset(rt, 0, sizeof(struct range_test));

	strcpy(rt->name, "Even");
	rt->age = 31;

	hexdump((unsigned char *)rt, sizeof (struct range_test), (unsigned char *)(&id));
}

void init_range_test4(short id) 
{
	struct range_test *rt = (struct range_test *)malloc(sizeof(struct range_test));
	memset(rt, 0, sizeof(struct range_test));

	strcpy(rt->name, "Jaroslav");
	rt->age = 101;

	hexdump((unsigned char *)rt, sizeof (struct range_test), (unsigned char *)(&id));
}

void init_struct_test1(short id) 
{
	struct struct_test *st = (struct struct_test *)malloc(sizeof(struct struct_test));
	memset(st, 0, sizeof(struct struct_test));

	st->id=1;
	strcpy(st->username.u1.username, "Jaroslav");
	strcpy(st->username.u1.password, "Jaroslaf");
	strcpy(st->username.n1.first_name, "Jaroslav");
	strcpy(st->username.n1.last_name, "Fibichr");
	strcpy(st->adress, "Bakkevei");
	st->number = 12;
	st->pcode.code = 7000;
	strcpy(st->pcode.place, "Trondheim");

	hexdump((unsigned char *)st, sizeof (struct struct_test), (unsigned char *)(&id));
}

void init_struct_test2(short id) 
{
	struct struct_test *st = (struct struct_test *)malloc(sizeof(struct struct_test));
	memset(st, 0, sizeof(struct struct_test));

	st->id=1;
	strcpy(st->username.u1.username, "Terje");
	strcpy(st->username.u1.password, "Snarby");
	strcpy(st->username.n1.first_name, "test");
	strcpy(st->username.n1.last_name, "test1234");
	strcpy(st->adress, "Sentrum");
	st->number = 99;
	st->pcode.code = 7005;
	strcpy(st->pcode.place, "Molde");

	hexdump((unsigned char *)st, sizeof (struct struct_test), (unsigned char *)(&id));
}

void init_struct_with_struct_test1(short id) 
{
	struct struct_within_struct_test *st = (struct struct_within_struct_test *)malloc(sizeof(struct struct_within_struct_test));
	memset(st, 0, sizeof(struct struct_within_struct_test));

	st->prime = 2;
	st->astruct.id = 1;
	st->astruct.mnd = DEC;

	hexdump((unsigned char *)st, sizeof (struct struct_within_struct_test), (unsigned char *)(&id));
}

void init_struct_with_struct_test2(short id) 
{
	struct struct_within_struct_test *st = (struct struct_within_struct_test *)malloc(sizeof(struct struct_within_struct_test));
	memset(st, 0, sizeof(struct struct_within_struct_test));

	st->prime = 3;
	st->astruct.id = 2;
	st->astruct.mnd = OCT;

	hexdump((unsigned char *)st, sizeof (struct struct_within_struct_test), (unsigned char *)(&id));
}

void init_struct_with_struct_test3(short id) 
{
	struct struct_within_struct_test *st = (struct struct_within_struct_test *)malloc(sizeof(struct struct_within_struct_test));
	memset(st, 0, sizeof(struct struct_within_struct_test));

	st->prime = 5;
	st->astruct.id = 3;
	st->astruct.mnd = FEB;

	hexdump((unsigned char *)st, sizeof (struct struct_within_struct_test), (unsigned char *)(&id));
}

void init_union_test1(short id) 
{
	struct union_within_struct *ut = (struct union_within_struct *)malloc(sizeof(struct union_within_struct));
	memset(ut, 0, sizeof(struct union_within_struct));

	ut->a = 1;
	ut->union_member.int_member = 1;
	ut->b = 1.1f;

	hexdump((unsigned char *)ut, sizeof (struct union_within_struct), (unsigned char *)(&id));
}

void init_union_test2(short id) 
{
	struct union_within_struct *ut = (struct union_within_struct *)malloc(sizeof(struct union_within_struct));
	memset(ut, 0, sizeof(struct union_within_struct));

	ut->a = 2;
	ut->union_member.float_member = 3.14f;
	ut->b = 2.2f;

	hexdump((unsigned char *)ut, sizeof (struct union_within_struct), (unsigned char *)(&id));
}

void init_union_test3(short id) 
{
	struct union_within_struct *ut = (struct union_within_struct *)malloc(sizeof(struct union_within_struct));
	memset(ut, 0, sizeof(struct union_within_struct));

	ut->a = 3;
	ut->union_member.long_long_member = 0x7FFFFFFFFFFFFFF7;
	ut->b = 3.3f;

	hexdump((unsigned char *)ut, sizeof (struct union_within_struct), (unsigned char *)(&id));
}

struct trailer {
	struct trailer_test t;
	char asn[40];
};

void init_trailer_test1(short id) 
{
	struct trailer *t = (struct trailer *)malloc(sizeof(struct trailer));
	memset(t, 0, sizeof(struct trailer));

	t->t.tmp[0] = 1.0;
	t->t.tmp[1] = 2.0;
	t->t.tmp[2] = 3.0;
	t->t.tmp[3] = 4.0;
	t->t.tmp[4] = 5.0;
	t->t.asn1_count = 2;
	memcpy(t->asn, "\x02\x01\x00\x00\x00\x00\x02\x01\x01\x00\x00\x00\x16\x03\x48\x45\x59\x02\x01\x02\x00\x00\x00\x02\x02\x01\x00\x00\x00\x16\x03\x48\x45\x59", 34);

	hexdump((unsigned char *)t, sizeof (struct trailer), (unsigned char *)(&id));
}

void init_trailer_test2(short id) 
{
	struct trailer *t = (struct trailer *)malloc(sizeof(struct trailer));
	memset(t, 0, sizeof(struct trailer));

	t->t.tmp[0] = 10.0;
	t->t.tmp[1] = 20.0;
	t->t.tmp[2] = 30.0;
	t->t.tmp[3] = 40.0;
	t->t.tmp[4] = 50.0;
	t->t.asn1_count = 3;
	memcpy(t->asn, "\x02\x01\x40\x00\x00\x00\x02\x01\x00\x00\x00\x00\x02\x02\x10\x00\x00\x00\x16\x03\x48\x4d\x4d\x02\x02\x12\x4\x00\x00\x02\x01\x10\x00\x00\x00\x16\x03\x48\x45\x59", 40);

	hexdump((unsigned char *)t, sizeof (struct trailer), (unsigned char *)(&id));
}

void init_typedef_test1(short id) 
{
	struct typedef_test *tt = (struct typedef_test *)malloc(sizeof(struct typedef_test));
	int a, b, c;
	memset(tt, 0, sizeof(struct trailer));
	tt->a = 2040;
	tt->b[0].a = 1;
	tt->b[0].b = 2;
	tt->b[1].a = 3;
	tt->b[1].b = 4;
	tt->c = 29102011;
	tt->d[0].a = 1;
	tt->d[0].b = 2;
	tt->d[1].a = 3;
	tt->d[1].b = 4;
	tt->e = 9;
	tt->f[0][0] = 'x';
	tt->f[0][1] = 'q';
	tt->f[1][0] = 'p';
	tt->f[1][1] = 'j';
	tt->g = -1;
	tt->h[0] = &a;
	tt->h[1] = &b;
	tt->h[2] = &c;
	tt->i = 256*256;
	tt->j[0] = FLOPPY;
	tt->j[1] = DVD;
	tt->k = 3.14f;
	tt->l[0].intage = 32;
	tt->l[1].charage[0] = ' ';
	tt->l[1].charage[1] = '3';
	tt->l[1].charage[2] = '2';
	tt->m = 2.718281828;

	hexdump((unsigned char *)tt, sizeof (struct typedef_test), (unsigned char *)(&id));
}

int main() 
{
	init_basic(22);
	init_platform_test1(670);
	init_platform_test2(670);
	init_alignment_test1(667);
	init_alignment_test2(667);
	init_array_test(16); 
	init_bitstring_test1(13);
	init_bitstring_test2(13);
	init_bitstring_test3(13);
	init_bitstring_test4(13);
	init_cenum_test1(11);
	init_cenum_test2(11);
	init_cenum_test3(11);
	init_cenum_test4(11);
	init_custom_test1(74);
	init_enum_test1(10);
	init_enum_test2(10);
	init_enum_test3(10);
	init_enum_test4(10);
	init_keyword_test1(255);
	init_range_test1(9); 
	init_range_test2(9); 
	init_range_test3(9); 
	init_range_test4(9); 
	init_struct_test1(17);
	init_struct_test2(17);
	init_struct_with_struct_test1(12);
	init_struct_with_struct_test2(12);
	init_struct_with_struct_test3(12);
	init_union_test1(160);
	init_union_test2(160);
	init_union_test3(160);
	init_trailer_test1(66);
	init_trailer_test2(66);
	init_typedef_test1(8);

	return 0;
}
