#define STRING_LEN 10

struct range_test {
    char name[STRING_LEN];
    int age;
};
