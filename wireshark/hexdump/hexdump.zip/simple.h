struct basic {
    // Chars
    char name;
    signed char white;
    unsigned char grey;

    // Ints
    short z;
    int size;
    signed int y;
    unsigned int x;
    short int yellow;
    unsigned short int black;
    long int orange;
    long long int red;
    unsigned long long pink;
    long blue;
    signed int tester;

    // Single and double precision
    float in;
    double end;
    //long double car;
};
