struct struct_within_struct_test {
	int prime;
	struct cenum_test astruct;
};
