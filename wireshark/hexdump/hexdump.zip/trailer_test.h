struct trailer_test {
    float tmp[5];
    int asn1_count;
};
